"""
Module 1: Video Reader
Handles loading, metadata extraction, and frame iteration from drone video.
"""

import cv2
import os
from typing import Generator, Dict, Any


class VideoReader:
    """
    Reads drone video files and yields frames for processing.

    Supports:
    - MP4, AVI, MOV, MKV, RTSP streams
    - Frame skipping for speed
    - Optional resize
    - Metadata extraction
    """

    def __init__(self, video_path: str, config: dict):
        self.video_path = video_path
        self.config = config
        self.frame_skip = config.get("video", {}).get("frame_skip", 1)
        self.max_frames = config.get("video", {}).get("max_frames", None)
        self.resize_width = config.get("video", {}).get("resize_width", None)

        if not os.path.exists(video_path):
            raise FileNotFoundError(f"Video not found: {video_path}")

        self._cap = cv2.VideoCapture(video_path)
        if not self._cap.isOpened():
            raise ValueError(f"Cannot open video: {video_path}")

    def get_metadata(self) -> Dict[str, Any]:
        """Return video metadata dictionary."""
        cap = self._cap
        fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        duration = total_frames / fps if fps > 0 else 0

        return {
            "filename": os.path.basename(self.video_path),
            "path": self.video_path,
            "fps": fps,
            "total_frames": total_frames,
            "width": width,
            "height": height,
            "duration_sec": duration,
            "codec": self._get_codec(),
        }

    def _get_codec(self) -> str:
        fourcc = int(self._cap.get(cv2.CAP_PROP_FOURCC))
        return "".join([chr((fourcc >> 8 * i) & 0xFF) for i in range(4)]).strip()

    def frame_generator(self) -> Generator[Dict[str, Any], None, None]:
        """
        Yields frame dicts: {frame, frame_index, timestamp_sec, width, height}
        Applies frame_skip and max_frames limits.
        """
        meta = self.get_metadata()
        fps = meta["fps"]
        frame_index = 0
        yielded = 0

        self._cap.set(cv2.CAP_PROP_POS_FRAMES, 0)

        while True:
            ret, frame = self._cap.read()
            if not ret:
                break

            frame_index += 1

            # Apply frame skip
            if (frame_index - 1) % self.frame_skip != 0:
                continue

            # Resize if configured
            if self.resize_width and frame.shape[1] != self.resize_width:
                scale = self.resize_width / frame.shape[1]
                new_h = int(frame.shape[0] * scale)
                frame = cv2.resize(frame, (self.resize_width, new_h))

            timestamp = (frame_index - 1) / fps if fps > 0 else 0

            yield {
                "frame": frame,
                "frame_index": frame_index,
                "timestamp_sec": timestamp,
                "width": frame.shape[1],
                "height": frame.shape[0],
            }

            yielded += 1
            if self.max_frames and yielded >= self.max_frames:
                break

        self._cap.release()

    def __del__(self):
        if hasattr(self, "_cap") and self._cap.isOpened():
            self._cap.release()
