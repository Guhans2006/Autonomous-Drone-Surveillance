"""
Module 3: Object Tracker
Multi-object tracking using IoU-based simple tracker.
Assigns persistent Track IDs across frames.

For production: swap in DeepSORT or ByteTrack for superior re-identification.
"""

import numpy as np
from typing import List, Dict, Any


class Track:
    """Represents a single tracked object."""
    _id_counter = 1

    def __init__(self, detection: dict):
        self.track_id = Track._id_counter
        Track._id_counter += 1
        self.hits = 1
        self.age = 0
        self.missed_frames = 0
        self.history: List[dict] = [detection]
        self.class_label = detection["class_label"]
        self.last_bbox = detection["bbox"]
        self.velocities: List[tuple] = []  # (vx, vy) per frame

    def update(self, detection: dict):
        cx_prev = (self.last_bbox[0] + self.last_bbox[2]) / 2
        cy_prev = (self.last_bbox[1] + self.last_bbox[3]) / 2
        cx_new = detection["center_x"]
        cy_new = detection["center_y"]
        self.velocities.append((cx_new - cx_prev, cy_new - cy_prev))
        if len(self.velocities) > 10:
            self.velocities.pop(0)

        self.last_bbox = detection["bbox"]
        self.hits += 1
        self.missed_frames = 0
        self.history.append(detection)

    @property
    def velocity(self) -> float:
        """Average velocity magnitude over recent frames."""
        if not self.velocities:
            return 0.0
        mags = [np.sqrt(vx**2 + vy**2) for vx, vy in self.velocities]
        return float(np.mean(mags))

    @property
    def confirmed(self) -> bool:
        return self.hits >= 3


class ObjectTracker:
    """
    Simple IoU-based multi-object tracker.
    Assigns track IDs to detections across frames.
    """

    def __init__(self, config: dict):
        tracker_cfg = config.get("tracker", {})
        self.max_age = tracker_cfg.get("max_age", 30)
        self.min_hits = tracker_cfg.get("min_hits", 3)
        self.iou_threshold = tracker_cfg.get("iou_threshold", 0.3)
        self.active_tracks: List[Track] = []

    def update(self, detections: List[dict], frame, timestamp: float) -> List[Dict[str, Any]]:
        """
        Match detections to existing tracks.
        Returns detections with track_id and velocity injected.
        """
        if not detections:
            self._age_tracks()
            return []

        if not self.active_tracks:
            for det in detections:
                self.active_tracks.append(Track(det))
        else:
            self._match_and_update(detections)

        self._age_tracks()

        # Return detections enriched with tracking info
        output = []
        for det in detections:
            # Find matching track
            track = self._find_track_for_detection(det)
            det_out = dict(det)
            if track:
                det_out["track_id"] = track.track_id
                det_out["velocity"] = round(track.velocity, 2)
                det_out["track_hits"] = track.hits
                det_out["confirmed"] = track.confirmed
            else:
                det_out["track_id"] = -1
                det_out["velocity"] = 0.0
                det_out["track_hits"] = 1
                det_out["confirmed"] = False
            output.append(det_out)

        return output

    def _match_and_update(self, detections: List[dict]):
        """IoU matching between detections and active tracks."""
        unmatched_dets = list(range(len(detections)))
        matched_track_ids = set()

        for det_idx, det in enumerate(detections):
            best_iou = self.iou_threshold
            best_track = None

            for track in self.active_tracks:
                if track.track_id in matched_track_ids:
                    continue
                iou = self._iou(det["bbox"], track.last_bbox)
                if iou > best_iou:
                    best_iou = iou
                    best_track = track

            if best_track:
                best_track.update(det)
                matched_track_ids.add(best_track.track_id)
                unmatched_dets.remove(det_idx)

        # Create new tracks for unmatched detections
        for idx in unmatched_dets:
            self.active_tracks.append(Track(detections[idx]))

    def _age_tracks(self):
        """Increment age of unmatched tracks; remove stale ones."""
        for track in self.active_tracks:
            track.age += 1
            track.missed_frames += 1

        self.active_tracks = [t for t in self.active_tracks
                              if t.missed_frames <= self.max_age]

    def _find_track_for_detection(self, det: dict):
        """Find the track whose bbox best matches the detection."""
        best_iou = 0.2
        best_track = None
        for track in self.active_tracks:
            iou = self._iou(det["bbox"], track.last_bbox)
            if iou > best_iou:
                best_iou = iou
                best_track = track
        return best_track

    @staticmethod
    def _iou(bbox1, bbox2) -> float:
        """Compute Intersection over Union for two bboxes [x1,y1,x2,y2]."""
        x1 = max(bbox1[0], bbox2[0])
        y1 = max(bbox1[1], bbox2[1])
        x2 = min(bbox1[2], bbox2[2])
        y2 = min(bbox1[3], bbox2[3])

        inter = max(0, x2 - x1) * max(0, y2 - y1)
        if inter == 0:
            return 0.0

        a1 = (bbox1[2] - bbox1[0]) * (bbox1[3] - bbox1[1])
        a2 = (bbox2[2] - bbox2[0]) * (bbox2[3] - bbox2[1])
        union = a1 + a2 - inter
        return inter / union if union > 0 else 0.0
