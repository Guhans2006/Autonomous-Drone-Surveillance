"""
DISHTI - Drone Intelligence System for High-value Target Identification
AI Module for UAS Autonomous Recognition, Identification and Targeting
Main Pipeline Runner
"""

import argparse
import time
import sys
import os
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from modules.video_reader import VideoReader
from modules.detector import TargetDetector
from modules.tracker import ObjectTracker
from modules.threat_scorer import ThreatScorer
from modules.report_generator import ReportGenerator
from modules.logger import setup_logger
from config.config_loader import load_config


def run_pipeline(video_path: str, config_path: str = "config/config.yaml",
                 output_dir: str = "outputs/reports", show_preview: bool = False):
    logger = setup_logger("DISHTI-Pipeline")
    logger.info("=" * 60)
    logger.info("DISHTI - Drone Intelligence System")
    logger.info("Initialising pipeline...")
    logger.info("=" * 60)

    config = load_config(config_path)
    os.makedirs(output_dir, exist_ok=True)

    pipeline_start = time.time()

    logger.info("[1/5] Loading video...")
    reader = VideoReader(video_path, config)
    video_meta = reader.get_metadata()
    logger.info(f"  Video: {video_meta['filename']}")
    logger.info(f"  Resolution: {video_meta['width']}x{video_meta['height']} @ {video_meta['fps']:.1f} FPS")
    logger.info(f"  Duration: {video_meta['duration_sec']:.1f}s ({video_meta['total_frames']} frames)")

    logger.info("[2/5] Initialising detection model...")
    detector = TargetDetector(config)
    logger.info(f"  Model: {config['model']['name']}")
    logger.info(f"  Confidence threshold: {config['model']['confidence_threshold']}")

    logger.info("[3/5] Initialising object tracker...")
    tracker = ObjectTracker(config)

    logger.info("[4/5] Initialising threat scoring engine...")
    scorer = ThreatScorer(config)

    logger.info("[5/5] Processing video frames...")

    all_detections = []
    timeline_events = []
    frame_count = 0

    for frame_data in reader.frame_generator():
        frame = frame_data["frame"]
        frame_idx = frame_data["frame_index"]
        timestamp = frame_data["timestamp_sec"]
        frame_count += 1

        raw_detections = detector.detect(frame, frame_idx, timestamp)

        if raw_detections:
            tracked_objects = tracker.update(raw_detections, frame, timestamp)
            scored_objects = scorer.score(tracked_objects, frame_data)
            all_detections.extend(scored_objects)

            high_threat = [d for d in scored_objects if d.get("threat_level") == "HIGH"]
            for obj in high_threat:
                timeline_events.append({
                    "timestamp": timestamp,
                    "frame_index": frame_idx,
                    "event": f"HIGH THREAT detected: {obj['class_label']} (ID:{obj['track_id']})",
                    "confidence": obj["confidence"]
                })
                logger.warning(f"  HIGH THREAT @ {timestamp:.1f}s — {obj['class_label']}")

        if frame_count % 100 == 0:
            pct = (frame_count / video_meta['total_frames']) * 100
            logger.info(f"  Progress: {frame_count}/{video_meta['total_frames']} frames ({pct:.0f}%)")

    inference_time = time.time() - pipeline_start

    logger.info("Generating intelligence report...")
    generator = ReportGenerator(config, output_dir)
    report_path = generator.generate(
        detections=all_detections,
        video_meta=video_meta,
        timeline_events=timeline_events,
        inference_time=inference_time
    )

    logger.info(f"Pipeline complete in {inference_time:.1f}s | Detections: {len(all_detections)}")
    logger.info(f"Report: {report_path}")
    return report_path


def main():
    parser = argparse.ArgumentParser(description="DISHTI Drone Video Analysis")
    parser.add_argument("video", help="Path to drone video file")
    parser.add_argument("--config", default="config/config.yaml")
    parser.add_argument("--output", default="outputs/reports")
    parser.add_argument("--preview", action="store_true")
    args = parser.parse_args()

    if not os.path.exists(args.video):
        print(f"Error: Video not found: {args.video}")
        sys.exit(1)

    report_path = run_pipeline(args.video, args.config, args.output, args.preview)
    print(f"\nReport: {report_path}")


if __name__ == "__main__":
    main()
