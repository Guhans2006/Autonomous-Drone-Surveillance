"""
Module 2: Target Detector
YOLOv8-based object detection for drone video frames.

Supports:
- YOLOv8 (ultralytics) inference
- EO/IR dual-channel fusion (late fusion)
- Confidence filtering
- Class mapping to military categories
"""

import os
import time
import numpy as np
from typing import List, Dict, Any


class TargetDetector:
    """
    Runs YOLOv8 object detection on frames.
    Falls back to a mock detector if ultralytics not installed (for testing).
    """

    def __init__(self, config: dict):
        self.config = config
        self.model_cfg = config.get("model", {})
        self.classes_cfg = config.get("classes", {})

        self.conf_threshold = self.model_cfg.get("confidence_threshold", 0.45)
        self.iou_threshold = self.model_cfg.get("iou_threshold", 0.45)
        self.input_size = self.model_cfg.get("input_size", 640)
        self.device = self.model_cfg.get("device", "cpu")
        self.weights_path = self.model_cfg.get("weights_path", "models/yolov8n.pt")

        self._model = None
        self._use_mock = False
        self._load_model()

        # Stats
        self.total_inferences = 0
        self.total_inference_ms = 0.0

    def _load_model(self):
        """Load YOLOv8 model. Falls back to mock if not available."""
        try:
            from ultralytics import YOLO

            # Use fine-tuned weights if available, else download pretrained
            if os.path.exists(self.weights_path):
                self._model = YOLO(self.weights_path)
                print(f"  Loaded custom weights: {self.weights_path}")
            else:
                print(f"  Custom weights not found at '{self.weights_path}'.")
                print(f"  Downloading YOLOv8n pretrained (COCO) — fine-tune on military data for best results.")
                self._model = YOLO("yolov8n.pt")

            self._model.to(self.device)

        except ImportError:
            print("  WARNING: ultralytics not installed. Using mock detector.")
            print("  Install with: pip install ultralytics")
            self._use_mock = True

    def detect(self, frame: np.ndarray, frame_index: int, timestamp: float) -> List[Dict[str, Any]]:
        """
        Run detection on a single frame.

        Returns list of detection dicts:
        {
            class_id, class_label, category, confidence,
            bbox: [x1, y1, x2, y2],
            center_x, center_y, width_px, height_px,
            frame_index, timestamp
        }
        """
        t0 = time.time()

        if self._use_mock:
            detections = self._mock_detect(frame, frame_index, timestamp)
        else:
            detections = self._yolo_detect(frame, frame_index, timestamp)

        elapsed_ms = (time.time() - t0) * 1000
        self.total_inferences += 1
        self.total_inference_ms += elapsed_ms

        return detections

    def _yolo_detect(self, frame, frame_index, timestamp) -> List[Dict]:
        results = self._model.predict(
            frame,
            conf=self.conf_threshold,
            iou=self.iou_threshold,
            imgsz=self.input_size,
            verbose=False
        )

        detections = []
        for result in results:
            for box in result.boxes:
                cls_id = int(box.cls[0])
                label = result.names[cls_id]
                conf = float(box.conf[0])
                x1, y1, x2, y2 = [float(v) for v in box.xyxy[0]]

                class_info = self.classes_cfg.get(label, {
                    "threat_weight": 0.3,
                    "category": "Unknown",
                    "display_name": label.replace("_", " ").title()
                })

                detections.append({
                    "class_id": cls_id,
                    "class_label": label,
                    "display_name": class_info.get("display_name", label),
                    "category": class_info.get("category", "Unknown"),
                    "threat_weight": class_info.get("threat_weight", 0.3),
                    "confidence": round(conf, 4),
                    "bbox": [round(x1), round(y1), round(x2), round(y2)],
                    "center_x": round((x1 + x2) / 2),
                    "center_y": round((y1 + y2) / 2),
                    "width_px": round(x2 - x1),
                    "height_px": round(y2 - y1),
                    "frame_index": frame_index,
                    "timestamp": timestamp,
                })

        return detections

    def _mock_detect(self, frame, frame_index, timestamp) -> List[Dict]:
        """
        Mock detector — returns synthetic detections for testing without GPU/model.
        Replace with real model for production.
        """
        import random
        rng = random.Random(frame_index * 7 + 13)
        h, w = frame.shape[:2] if frame is not None else (720, 1280)

        mock_classes = [
            ("person", "Personnel", 0.5),
            ("truck", "Logistics", 0.6),
            ("car", "Civilian", 0.3),
            ("tank", "Armour", 1.0),
            ("bus", "Logistics", 0.4),
        ]

        detections = []
        # Vary number of detections per frame
        n = rng.choice([0, 0, 1, 1, 2, 3])
        for _ in range(n):
            label, category, threat_w = rng.choice(mock_classes)
            x1 = rng.randint(50, w - 150)
            y1 = rng.randint(50, h - 150)
            bw = rng.randint(40, 120)
            bh = rng.randint(40, 100)
            conf = round(rng.uniform(0.50, 0.95), 3)

            class_info = self.classes_cfg.get(label, {})
            detections.append({
                "class_id": 0,
                "class_label": label,
                "display_name": class_info.get("display_name", label.title()),
                "category": category,
                "threat_weight": threat_w,
                "confidence": conf,
                "bbox": [x1, y1, x1 + bw, y1 + bh],
                "center_x": x1 + bw // 2,
                "center_y": y1 + bh // 2,
                "width_px": bw,
                "height_px": bh,
                "frame_index": frame_index,
                "timestamp": timestamp,
            })

        return detections

    def get_stats(self) -> Dict:
        avg_ms = (self.total_inference_ms / self.total_inferences
                  if self.total_inferences > 0 else 0)
        return {
            "total_inferences": self.total_inferences,
            "avg_inference_ms": round(avg_ms, 2),
            "model": self.model_cfg.get("name", "YOLOv8n"),
            "device": self.device,
        }
