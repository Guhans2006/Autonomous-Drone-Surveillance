"""Config loader with defaults fallback."""

import yaml
import os


def load_config(config_path: str = "config/config.yaml") -> dict:
    """Load YAML config. Falls back to defaults if file not found."""
    if not os.path.exists(config_path):
        return _default_config()

    with open(config_path, "r") as f:
        config = yaml.safe_load(f)

    return config


def _default_config() -> dict:
    return {
        "mission": {"name": "DEFAULT", "operator": "OPERATOR",
                    "platform": "UAV", "sensor": "EO", "altitude_m": 100,
                    "area_of_interest": "UNKNOWN"},
        "model": {"name": "YOLOv8n", "weights_path": "models/yolov8n.pt",
                  "confidence_threshold": 0.45, "iou_threshold": 0.45,
                  "input_size": 640, "device": "cpu", "half_precision": False},
        "video": {"frame_skip": 2, "max_frames": None, "resize_width": None},
        "tracker": {"max_age": 30, "min_hits": 3, "iou_threshold": 0.3},
        "threat_scoring": {
            "weights": {"class_threat": 0.40, "confidence": 0.25,
                        "proximity_center": 0.20, "motion_velocity": 0.15},
            "thresholds": {"high": 0.70, "medium": 0.45, "low": 0.0}
        },
        "classes": {
            "person":    {"threat_weight": 0.5, "category": "Personnel",  "display_name": "Personnel"},
            "car":       {"threat_weight": 0.3, "category": "Civilian",   "display_name": "Vehicle"},
            "truck":     {"threat_weight": 0.6, "category": "Logistics",  "display_name": "Truck"},
            "tank":      {"threat_weight": 1.0, "category": "Armour",     "display_name": "Tank"},
            "bus":       {"threat_weight": 0.4, "category": "Logistics",  "display_name": "Bus"},
            "motorcycle":{"threat_weight": 0.4, "category": "Personnel",  "display_name": "Motorcycle"},
        },
        "report": {"classification": "CONFIDENTIAL",
                   "origin_lat": 28.6139, "origin_lon": 77.2090,
                   "meters_per_pixel": 0.15, "coordinate_format": "WGS84"},
        "output": {"save_annotated_video": False, "save_detection_json": True, "report_format": "docx"}
    }
