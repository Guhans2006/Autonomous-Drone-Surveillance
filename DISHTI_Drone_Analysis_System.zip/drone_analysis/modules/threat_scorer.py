"""
Module 4: Threat Scorer & Prioritisation Engine
Classifies detected objects into HIGH / MEDIUM / LOW threat levels
using a weighted multi-factor scoring function.

Score formula:
  S = w1*class_threat + w2*confidence + w3*proximity_to_center + w4*velocity_norm

All factors are normalised to [0, 1].
"""

import numpy as np
from typing import List, Dict, Any


class ThreatScorer:
    """
    Assigns threat scores and levels to tracked detections.
    Adds GPS coordinate estimate (based on pixel-to-meter projection).
    """

    def __init__(self, config: dict):
        scoring_cfg = config.get("threat_scoring", {})
        weights = scoring_cfg.get("weights", {})
        thresholds = scoring_cfg.get("thresholds", {})
        report_cfg = config.get("report", {})

        self.w_class    = weights.get("class_threat", 0.40)
        self.w_conf     = weights.get("confidence", 0.25)
        self.w_prox     = weights.get("proximity_center", 0.20)
        self.w_vel      = weights.get("motion_velocity", 0.15)

        self.th_high    = thresholds.get("high", 0.70)
        self.th_medium  = thresholds.get("medium", 0.45)

        # Geo-referencing
        self.origin_lat      = report_cfg.get("origin_lat", 28.6139)
        self.origin_lon      = report_cfg.get("origin_lon", 77.2090)
        self.meters_per_px   = report_cfg.get("meters_per_pixel", 0.15)

        # Max expected velocity (pixels/frame) for normalisation
        self.max_velocity = 80.0

    def score(self, detections: List[dict], frame_data: dict) -> List[Dict[str, Any]]:
        """
        Score each detection and inject:
          - threat_score  (float 0–1)
          - threat_level  (HIGH / MEDIUM / LOW)
          - lat, lon      (estimated WGS84 coords)
          - priority_rank (1 = highest)
        """
        frame_w = frame_data.get("width", 1280)
        frame_h = frame_data.get("height", 720)

        scored = []
        for det in detections:
            s = self._compute_score(det, frame_w, frame_h)
            level = self._classify(s)
            lat, lon = self._pixel_to_latlon(det["center_x"], det["center_y"],
                                             frame_w, frame_h)
            det_out = dict(det)
            det_out["threat_score"]  = round(s, 4)
            det_out["threat_level"]  = level
            det_out["lat"]           = round(lat, 6)
            det_out["lon"]           = round(lon, 6)
            det_out["priority_rank"] = 0  # filled below
            scored.append(det_out)

        # Assign priority rank (1 = highest threat)
        scored.sort(key=lambda x: x["threat_score"], reverse=True)
        for i, det in enumerate(scored):
            det["priority_rank"] = i + 1

        return scored

    def _compute_score(self, det: dict, frame_w: int, frame_h: int) -> float:
        # Factor 1: Class-based threat weight
        f_class = det.get("threat_weight", 0.3)

        # Factor 2: Detection confidence
        f_conf = det.get("confidence", 0.5)

        # Factor 3: Proximity to frame centre (closer = higher threat)
        cx, cy = det.get("center_x", frame_w // 2), det.get("center_y", frame_h // 2)
        dist = np.sqrt((cx - frame_w / 2)**2 + (cy - frame_h / 2)**2)
        max_dist = np.sqrt((frame_w / 2)**2 + (frame_h / 2)**2)
        f_prox = 1.0 - (dist / max_dist) if max_dist > 0 else 0.5

        # Factor 4: Motion velocity (normalised)
        vel = det.get("velocity", 0.0)
        f_vel = min(vel / self.max_velocity, 1.0)

        score = (self.w_class * f_class
                 + self.w_conf  * f_conf
                 + self.w_prox  * f_prox
                 + self.w_vel   * f_vel)

        return float(np.clip(score, 0.0, 1.0))

    def _classify(self, score: float) -> str:
        if score >= self.th_high:
            return "HIGH"
        elif score >= self.th_medium:
            return "MEDIUM"
        else:
            return "LOW"

    def _pixel_to_latlon(self, px: float, py: float,
                          frame_w: int, frame_h: int):
        """
        Approximate pixel-to-WGS84 conversion.
        In production, replace with actual geo-referencing using
        UAV GPS telemetry, altitude, and camera calibration data.
        """
        dx_m = (px - frame_w / 2) * self.meters_per_px
        dy_m = (frame_h / 2 - py) * self.meters_per_px  # north = positive

        # 1 degree latitude ≈ 111320 m
        # 1 degree longitude ≈ 111320 * cos(lat) m
        import math
        lat = self.origin_lat + dy_m / 111320.0
        lon = self.origin_lon + dx_m / (111320.0 * math.cos(math.radians(self.origin_lat)))
        return lat, lon
