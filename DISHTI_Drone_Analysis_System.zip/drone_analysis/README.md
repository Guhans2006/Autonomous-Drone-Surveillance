# DISHTI — Drone Intelligence System for Target Identification

**AI Module for UAS Autonomous Recognition, Identification and Targeting**

---

## What This System Does

DISHTI analyses drone video footage and produces a complete intelligence report in `.docx` format containing:

- Every detected object (personnel, armour, vehicles, artillery, etc.)
- Threat classification: **HIGH / MEDIUM / LOW**
- Estimated GPS coordinates for each target
- Priority-ranked target list (most dangerous first)
- Full timeline of significant events
- AI performance metrics

---

## Quick Start

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Run the Demo (no drone video needed)

```bash
python demo.py
```
This creates a synthetic aerial video and runs the full pipeline. Check `outputs/reports/` for the generated `.docx` report.

### 3. Run on Your Own Video

```bash
python main.py path/to/your/drone_video.mp4
```

### 4. Run with Custom Config

```bash
python main.py video.mp4 --config config/config.yaml --output outputs/reports/
```

---

## Project Structure

```
drone_analysis/
├── main.py                      # Pipeline runner (entry point)
├── demo.py                      # Demo with synthetic video
├── requirements.txt
├── config/
│   ├── config.yaml              # All parameters (model, classes, thresholds)
│   └── config_loader.py         # Config loading utility
├── modules/
│   ├── video_reader.py          # Module 1: Video loading + frame iteration
│   ├── detector.py              # Module 2: YOLOv8 object detection
│   ├── tracker.py               # Module 3: IoU multi-object tracking
│   ├── threat_scorer.py         # Module 4: Threat scoring & GPS projection
│   ├── report_generator.py      # Module 5: Full DOCX report generation
│   └── logger.py                # Logging setup
├── models/
│   └── yolov8n.pt               # Place your fine-tuned weights here
├── data/
│   └── sample_frames/           # Test frames (optional)
└── outputs/
    └── reports/                 # Generated reports go here
```

---

## How It Works — Pipeline

```
Video → VideoReader → Detector (YOLOv8) → Tracker (IoU) → ThreatScorer → ReportGenerator
```

| Step | Module | What It Does |
|------|--------|-------------|
| 1 | `VideoReader` | Opens video, yields frames with metadata |
| 2 | `TargetDetector` | Runs YOLOv8 on each frame, returns bounding boxes + class |
| 3 | `ObjectTracker` | Assigns Track IDs across frames using IoU matching |
| 4 | `ThreatScorer` | Scores each object by class threat + confidence + proximity + velocity |
| 5 | `ReportGenerator` | Produces formatted `.docx` intelligence report |

---

## Threat Scoring Formula

```
Score = 0.40 × class_threat
      + 0.25 × detection_confidence
      + 0.20 × proximity_to_frame_center
      + 0.15 × normalised_velocity

HIGH   ≥ 0.70
MEDIUM ≥ 0.45
LOW    < 0.45
```

Weights are fully configurable in `config/config.yaml`.

---

## Upgrading for Production

### 1. Use Fine-Tuned Weights

Train YOLOv8 on military/aerial datasets (DOTA, VisDrone):
```bash
yolo train data=military.yaml model=yolov8n.pt epochs=100 imgsz=640
```
Place trained `.pt` file at `models/yolov8n_military.pt` and update `config.yaml`.

### 2. Enable GPU Inference

In `config.yaml`:
```yaml
model:
  device: "cuda"        # or "mps" for Apple Silicon
  half_precision: true  # FP16 for speed
```

### 3. Add Real GPS Geo-referencing

Replace the pixel-to-latlon estimation in `threat_scorer.py` with actual telemetry:
```python
# Read from UAV telemetry stream
lat, lon = gps_telemetry.get_target_coords(
    pixel_x=cx, pixel_y=cy,
    drone_lat=telemetry.lat, drone_lon=telemetry.lon,
    drone_alt=telemetry.altitude, heading=telemetry.heading,
    camera_fov=config["camera"]["fov_deg"]
)
```

### 4. Upgrade Tracker to DeepSORT

```bash
pip install deep_sort_realtime
```
In `tracker.py`, replace `ObjectTracker` with the DeepSORT wrapper for better re-identification across occlusions.

### 5. Add IR/Thermal Fusion

```python
# In detector.py — late fusion approach
eo_dets  = model_eo.predict(eo_frame)
ir_dets  = model_ir.predict(ir_frame)
merged   = fuse_detections(eo_dets, ir_dets)  # NMS across both
```

### 6. Edge Deployment (Jetson Orin)

Export to TensorRT:
```bash
yolo export model=yolov8n_military.pt format=engine device=0
```
Update `weights_path` in config to the `.engine` file.

---

## Configuration Reference (`config/config.yaml`)

| Key | Description |
|-----|-------------|
| `model.confidence_threshold` | Minimum detection confidence (0–1) |
| `model.device` | `cpu`, `cuda`, or `mps` |
| `video.frame_skip` | Process every Nth frame (2 = 2× faster) |
| `threat_scoring.thresholds.high` | Score threshold for HIGH threat |
| `classes.<name>.threat_weight` | How dangerous this class is (0–1) |
| `report.origin_lat/lon` | GPS origin for coordinate projection |
| `report.meters_per_pixel` | Ground sampling distance |

---

## Output Files

| File | Description |
|------|-------------|
| `DISHTI-YYYYMMDD-HHMMSS.docx` | Full intelligence report |
| `DISHTI-YYYYMMDD-HHMMSS_detections.json` | Raw detection data (machine-readable) |

---

## Legal & Ethical

This system is a **decision support tool only**. All outputs require human analyst verification before any action is taken. The system includes a mandatory Human-in-the-Loop disclaimer in every generated report.

---

*DISHTI — Built for DISC14 AI Module for UAS Problem Statement*
