"""
Module 5: Report Generator
Produces a fully-formatted DOCX intelligence report from detection data.

Sections:
  1. Cover / Classification Header
  2. Mission Parameters
  3. Executive Summary
  4. Object Detection Summary (aggregate counts + threat distribution)
  5. Detailed Target Log (full detection table)
  6. Timeline of Events
  7. Threat Prioritisation List
  8. Recommendations
  9. AI Module Performance Metrics
 10. Human-in-the-Loop Disclaimer
"""

import os
import json
from datetime import datetime
from typing import List, Dict, Any
from collections import Counter, defaultdict

from docx import Document
from docx.shared import Pt, RGBColor, Inches, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.oxml.ns import qn
from docx.oxml import OxmlElement


# ── Colour palette ────────────────────────────────────────────────────────────
DARK_BG    = RGBColor(0x1C, 0x27, 0x4B)   # deep navy
ACCENT     = RGBColor(0x00, 0x88, 0xFF)   # bright blue
HIGH_RED   = RGBColor(0xC0, 0x00, 0x00)
MED_AMBER  = RGBColor(0xFF, 0x8C, 0x00)
LOW_GREEN  = RGBColor(0x37, 0x86, 0x34)
HEADER_BG  = RGBColor(0x1C, 0x27, 0x4B)
ROW_ALT    = RGBColor(0xF0, 0xF4, 0xFF)
WHITE      = RGBColor(0xFF, 0xFF, 0xFF)
BLACK      = RGBColor(0x00, 0x00, 0x00)
MUTED      = RGBColor(0x60, 0x60, 0x60)


def _set_cell_bg(cell, rgb: RGBColor):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    hex_color = f"{rgb[0]:02X}{rgb[1]:02X}{rgb[2]:02X}"
    shd.set(qn("w:fill"), hex_color)
    tcPr.append(shd)


def _run_color(run, rgb: RGBColor):
    run.font.color.rgb = rgb


def _bold_cell(cell, text: str, size: int = 10, color: RGBColor = None, bg: RGBColor = None, align=None):
    cell.text = ""
    p = cell.paragraphs[0]
    if align:
        p.alignment = align
    run = p.add_run(text)
    run.bold = True
    run.font.size = Pt(size)
    if color:
        run.font.color.rgb = color
    if bg:
        _set_cell_bg(cell, bg)


def _set_col_widths(table, widths: list):
    """Set column widths in inches."""
    for row in table.rows:
        for i, cell in enumerate(row.cells):
            if i < len(widths):
                cell.width = Inches(widths[i])


class ReportGenerator:
    def __init__(self, config: dict, output_dir: str = "outputs/reports"):
        self.config = config
        self.output_dir = output_dir
        self.mission = config.get("mission", {})
        self.report_cfg = config.get("report", {})
        self.classification = self.report_cfg.get("classification", "CONFIDENTIAL")
        os.makedirs(output_dir, exist_ok=True)

    def generate(self,
                 detections: List[Dict],
                 video_meta: Dict,
                 timeline_events: List[Dict],
                 inference_time: float) -> str:

        doc = Document()
        self._setup_page(doc)

        stats = self._compute_stats(detections)
        timestamp = datetime.now()
        report_id = f"DISHTI-{timestamp.strftime('%Y%m%d-%H%M%S')}"

        self._header_banner(doc, report_id, timestamp)
        self._section_mission(doc, video_meta, timestamp)
        self._section_executive_summary(doc, stats, video_meta)
        self._section_detection_summary(doc, stats)
        self._section_target_log(doc, detections)
        self._section_timeline(doc, timeline_events)
        self._section_priority_list(doc, detections)
        self._section_recommendations(doc, stats)
        self._section_performance(doc, video_meta, inference_time, stats)
        self._section_disclaimer(doc)

        # Save report
        filename = f"{report_id}.docx"
        report_path = os.path.join(self.output_dir, filename)
        doc.save(report_path)

        # Also save raw detections JSON
        json_path = os.path.join(self.output_dir, f"{report_id}_detections.json")
        with open(json_path, "w") as f:
            json.dump({
                "report_id": report_id,
                "generated": timestamp.isoformat(),
                "video": video_meta,
                "stats": stats,
                "detections": detections,
                "timeline": timeline_events
            }, f, indent=2)

        return report_path

    # ── Page Setup ────────────────────────────────────────────────────────────
    def _setup_page(self, doc: Document):
        section = doc.sections[0]
        section.page_width = Inches(8.5)
        section.page_height = Inches(11)
        section.left_margin = Inches(0.9)
        section.right_margin = Inches(0.9)
        section.top_margin = Inches(0.75)
        section.bottom_margin = Inches(0.75)

    # ── Header Banner ─────────────────────────────────────────────────────────
    def _header_banner(self, doc: Document, report_id: str, ts: datetime):
        # Classification banner
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(f"◼  {self.classification}  ◼")
        run.bold = True
        run.font.size = Pt(11)
        run.font.color.rgb = HIGH_RED

        # Title
        p2 = doc.add_paragraph()
        p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p2.add_run("DISHTI")
        r.bold = True
        r.font.size = Pt(28)
        r.font.color.rgb = DARK_BG

        p3 = doc.add_paragraph()
        p3.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r2 = p3.add_run("Drone Intelligence System — Target Identification Report")
        r2.font.size = Pt(13)
        r2.font.color.rgb = MUTED

        # Report metadata table
        meta_table = doc.add_table(rows=1, cols=3)
        meta_table.style = "Table Grid"
        cells = meta_table.rows[0].cells
        for cell, text in zip(cells, [
            f"Report ID: {report_id}",
            f"Generated: {ts.strftime('%d %b %Y  %H:%M:%S')}",
            f"Mission: {self.mission.get('name', 'N/A')}"
        ]):
            cell.text = ""
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = p.add_run(text)
            run.font.size = Pt(9)
            run.font.color.rgb = WHITE
            _set_cell_bg(cell, DARK_BG)

        doc.add_paragraph()

    # ── Section 1: Mission Parameters ─────────────────────────────────────────
    def _section_mission(self, doc: Document, meta: Dict, ts: datetime):
        self._heading(doc, "1. MISSION PARAMETERS")

        t = doc.add_table(rows=0, cols=2)
        t.style = "Table Grid"

        rows_data = [
            ("Platform", self.mission.get("platform", "N/A")),
            ("Sensor System", self.mission.get("sensor", "N/A")),
            ("Altitude", f"{self.mission.get('altitude_m', 'N/A')} m"),
            ("Area of Interest", self.mission.get("area_of_interest", "N/A")),
            ("Operator Unit", self.mission.get("operator", "N/A")),
            ("Video File", meta.get("filename", "N/A")),
            ("Video Resolution", f"{meta.get('width')}×{meta.get('height')} @ {meta.get('fps', 0):.1f} FPS"),
            ("Video Duration", f"{meta.get('duration_sec', 0):.1f} seconds"),
            ("Total Frames", str(meta.get("total_frames", "N/A"))),
            ("Analysis Date", ts.strftime("%d %B %Y")),
        ]

        for i, (label, value) in enumerate(rows_data):
            row = t.add_row()
            row.cells[0].text = label
            row.cells[0].paragraphs[0].runs[0].bold = True
            row.cells[0].paragraphs[0].runs[0].font.size = Pt(9)
            row.cells[1].text = value
            row.cells[1].paragraphs[0].runs[0].font.size = Pt(9)
            if i % 2 == 0:
                _set_cell_bg(row.cells[0], ROW_ALT)
                _set_cell_bg(row.cells[1], ROW_ALT)

        _set_col_widths(t, [2.2, 4.6])
        doc.add_paragraph()

    # ── Section 2: Executive Summary ─────────────────────────────────────────
    def _section_executive_summary(self, doc: Document, stats: Dict, meta: Dict):
        self._heading(doc, "2. EXECUTIVE SUMMARY")

        high = stats["by_threat"]["HIGH"]
        med  = stats["by_threat"]["MEDIUM"]
        low  = stats["by_threat"]["LOW"]
        total = stats["total_detections"]

        summary = (
            f"Automated analysis of drone footage '{meta.get('filename', 'N/A')}' "
            f"({meta.get('duration_sec', 0):.0f} seconds) identified {total} target detections "
            f"across {meta.get('total_frames', 0)} frames. "
            f"Threat assessment: {high} HIGH-priority, {med} MEDIUM-priority, and {low} LOW-priority targets detected. "
        )

        if high > 0:
            summary += (f"IMMEDIATE ATTENTION REQUIRED: {high} high-threat object(s) identified. "
                        "Recommend rapid command review of prioritised target list (Section 7).")
        else:
            summary += "No immediate high-threat targets confirmed. Continued monitoring recommended."

        p = doc.add_paragraph(summary)
        p.runs[0].font.size = Pt(10)

        # Stats boxes
        doc.add_paragraph()
        st = doc.add_table(rows=1, cols=4)
        st.style = "Table Grid"
        labels = ["TOTAL DETECTIONS", "HIGH THREAT", "MEDIUM THREAT", "LOW THREAT"]
        values = [str(total), str(high), str(med), str(low)]
        colors = [DARK_BG, HIGH_RED, MED_AMBER, LOW_GREEN]
        for cell, lbl, val, col in zip(st.rows[0].cells, labels, values, colors):
            cell.text = ""
            p_l = cell.paragraphs[0]
            p_l.alignment = WD_ALIGN_PARAGRAPH.CENTER
            r_v = p_l.add_run(f"{val}\n")
            r_v.bold = True
            r_v.font.size = Pt(22)
            r_v.font.color.rgb = WHITE
            r_l = p_l.add_run(lbl)
            r_l.font.size = Pt(8)
            r_l.font.color.rgb = WHITE
            _set_cell_bg(cell, col)
            cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER

        doc.add_paragraph()

    # ── Section 3: Detection Summary ──────────────────────────────────────────
    def _section_detection_summary(self, doc: Document, stats: Dict):
        self._heading(doc, "3. OBJECT DETECTION SUMMARY")

        doc.add_paragraph("Table 3.1 — Detection Counts by Category:").runs[0].italic = True

        t = doc.add_table(rows=1, cols=4)
        t.style = "Table Grid"
        headers = ["Category", "Count", "% of Total", "Max Confidence"]
        for cell, h in zip(t.rows[0].cells, headers):
            _bold_cell(cell, h, size=9, color=WHITE, bg=DARK_BG,
                       align=WD_ALIGN_PARAGRAPH.CENTER)

        total = max(stats["total_detections"], 1)
        for i, (cat, data) in enumerate(sorted(stats["by_category"].items(),
                                               key=lambda x: x[1]["count"], reverse=True)):
            row = t.add_row()
            cells = row.cells
            cells[0].text = cat
            cells[1].text = str(data["count"])
            cells[1].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
            cells[2].text = f"{data['count'] / total * 100:.1f}%"
            cells[2].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
            cells[3].text = f"{data['max_conf']:.2f}"
            cells[3].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
            for cell in cells:
                for run in cell.paragraphs[0].runs:
                    run.font.size = Pt(9)
            if i % 2 == 1:
                for cell in cells:
                    _set_cell_bg(cell, ROW_ALT)

        _set_col_widths(t, [2.5, 1.0, 1.2, 1.5])
        doc.add_paragraph()

    # ── Section 4: Detailed Target Log ────────────────────────────────────────
    def _section_target_log(self, doc: Document, detections: List[Dict]):
        self._heading(doc, "4. DETAILED TARGET LOG")

        t = doc.add_table(rows=1, cols=8)
        t.style = "Table Grid"
        headers = ["Target ID", "Class", "Category", "Confidence", "Threat Level",
                   "Priority", "Latitude", "Longitude"]
        for cell, h in zip(t.rows[0].cells, headers):
            _bold_cell(cell, h, size=8, color=WHITE, bg=DARK_BG,
                       align=WD_ALIGN_PARAGRAPH.CENTER)

        threat_colors = {"HIGH": HIGH_RED, "MEDIUM": MED_AMBER, "LOW": LOW_GREEN}

        # Deduplicate by track_id (keep highest-confidence record)
        by_track = {}
        for det in detections:
            tid = det.get("track_id", -1)
            if tid not in by_track or det["confidence"] > by_track[tid]["confidence"]:
                by_track[tid] = det

        sorted_dets = sorted(by_track.values(), key=lambda x: x.get("priority_rank", 99))

        for i, det in enumerate(sorted_dets[:200]):  # cap at 200 rows
            row = t.add_row()
            cells = row.cells
            tid = det.get("track_id", "?")
            data = [
                f"TGT-{tid:03d}" if isinstance(tid, int) else f"TGT-{tid}",
                det.get("display_name", det.get("class_label", "Unknown")),
                det.get("category", "Unknown"),
                f"{det.get('confidence', 0):.3f}",
                det.get("threat_level", "LOW"),
                str(det.get("priority_rank", "?")),
                f"{det.get('lat', 0):.6f}",
                f"{det.get('lon', 0):.6f}",
            ]
            for cell, val in zip(cells, data):
                cell.text = val
                cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
                for run in cell.paragraphs[0].runs:
                    run.font.size = Pt(8)

            # Colour threat level cell
            tl = det.get("threat_level", "LOW")
            col = threat_colors.get(tl, LOW_GREEN)
            _set_cell_bg(cells[4], col)
            cells[4].paragraphs[0].runs[0].font.color.rgb = WHITE
            cells[4].paragraphs[0].runs[0].bold = True

            if i % 2 == 1:
                for j, cell in enumerate(cells):
                    if j != 4:
                        _set_cell_bg(cell, ROW_ALT)

        _set_col_widths(t, [0.7, 1.3, 1.0, 0.8, 0.8, 0.6, 1.0, 1.0])
        doc.add_paragraph()

    # ── Section 5: Timeline ───────────────────────────────────────────────────
    def _section_timeline(self, doc: Document, events: List[Dict]):
        self._heading(doc, "5. TIMELINE OF EVENTS")

        if not events:
            doc.add_paragraph("No significant timeline events recorded.").runs[0].italic = True
            doc.add_paragraph()
            return

        t = doc.add_table(rows=1, cols=4)
        t.style = "Table Grid"
        for cell, h in zip(t.rows[0].cells,
                           ["Timestamp (s)", "Frame #", "Event Description", "Confidence"]):
            _bold_cell(cell, h, size=9, color=WHITE, bg=DARK_BG)

        for i, ev in enumerate(events[:100]):
            row = t.add_row()
            cells = row.cells
            cells[0].text = f"{ev.get('timestamp', 0):.2f}s"
            cells[1].text = str(ev.get("frame_index", "?"))
            cells[2].text = ev.get("event", "")
            cells[3].text = f"{ev.get('confidence', 0):.3f}"
            for cell in cells:
                for run in cell.paragraphs[0].runs:
                    run.font.size = Pt(9)
            if i % 2 == 1:
                for cell in cells:
                    _set_cell_bg(cell, ROW_ALT)

        _set_col_widths(t, [1.0, 0.8, 4.4, 0.9])
        doc.add_paragraph()

    # ── Section 6: Priority List ──────────────────────────────────────────────
    def _section_priority_list(self, doc: Document, detections: List[Dict]):
        self._heading(doc, "6. THREAT PRIORITISATION LIST")

        by_track = {}
        for det in detections:
            tid = det.get("track_id", -1)
            if tid not in by_track or det.get("threat_score", 0) > by_track[tid].get("threat_score", 0):
                by_track[tid] = det

        top = sorted(by_track.values(), key=lambda x: x.get("threat_score", 0), reverse=True)[:20]

        t = doc.add_table(rows=1, cols=6)
        t.style = "Table Grid"
        for cell, h in zip(t.rows[0].cells,
                           ["Rank", "Target ID", "Class", "Threat Score", "Level", "Coordinates"]):
            _bold_cell(cell, h, size=9, color=WHITE, bg=DARK_BG, align=WD_ALIGN_PARAGRAPH.CENTER)

        threat_colors = {"HIGH": HIGH_RED, "MEDIUM": MED_AMBER, "LOW": LOW_GREEN}

        for i, det in enumerate(top):
            row = t.add_row()
            cells = row.cells
            tid = det.get("track_id", "?")
            tgt_id = f"TGT-{tid:03d}" if isinstance(tid, int) else f"TGT-{tid}"
            data = [
                str(i + 1),
                tgt_id,
                det.get("display_name", det.get("class_label", "?")),
                f"{det.get('threat_score', 0):.4f}",
                det.get("threat_level", "LOW"),
                f"{det.get('lat', 0):.5f}, {det.get('lon', 0):.5f}"
            ]
            for cell, val in zip(cells, data):
                cell.text = val
                cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
                for run in cell.paragraphs[0].runs:
                    run.font.size = Pt(9)

            tl = det.get("threat_level", "LOW")
            _set_cell_bg(cells[4], threat_colors.get(tl, LOW_GREEN))
            cells[4].paragraphs[0].runs[0].font.color.rgb = WHITE
            cells[4].paragraphs[0].runs[0].bold = True

            if i % 2 == 1:
                for j, cell in enumerate(cells):
                    if j != 4:
                        _set_cell_bg(cell, ROW_ALT)

        _set_col_widths(t, [0.5, 0.9, 1.4, 0.9, 0.8, 2.2])
        doc.add_paragraph()

    # ── Section 7: Recommendations ────────────────────────────────────────────
    def _section_recommendations(self, doc: Document, stats: Dict):
        self._heading(doc, "7. RECOMMENDATIONS")

        high = stats["by_threat"]["HIGH"]
        med  = stats["by_threat"]["MEDIUM"]

        recs = {
            "IMMEDIATE ACTIONS": [],
            "MONITORING ACTIONS": [],
            "FOLLOW-UP ISR REQUIREMENTS": []
        }

        if high > 0:
            recs["IMMEDIATE ACTIONS"].append(
                f"Review {high} HIGH-threat target(s) in Section 6 immediately. "
                "Cross-reference with ground intelligence before any action."
            )
            recs["IMMEDIATE ACTIONS"].append(
                "Notify command of confirmed high-priority threats with coordinates."
            )
        else:
            recs["IMMEDIATE ACTIONS"].append("No immediate high-threat targets. Maintain observation posture.")

        if med > 0:
            recs["MONITORING ACTIONS"].append(
                f"Continue surveillance of {med} MEDIUM-threat target(s). "
                "Schedule follow-up ISR pass within 30 minutes."
            )

        recs["MONITORING ACTIONS"].append("Archive footage and detections for intelligence database update.")
        recs["MONITORING ACTIONS"].append("Human analyst review of LOW-confidence detections recommended.")

        recs["FOLLOW-UP ISR REQUIREMENTS"].append(
            "Refly sector with IR sensor active during low-light conditions for thermal signature confirmation."
        )
        recs["FOLLOW-UP ISR REQUIREMENTS"].append(
            "Expand search radius by 20% to cover potential target egress routes."
        )

        for category, items in recs.items():
            p = doc.add_paragraph()
            run = p.add_run(f"{category}:")
            run.bold = True
            run.font.size = Pt(10)
            run.font.color.rgb = DARK_BG
            for item in items:
                bp = doc.add_paragraph(style="List Bullet")
                bp.add_run(item).font.size = Pt(9)

        doc.add_paragraph()

    # ── Section 8: Performance Metrics ────────────────────────────────────────
    def _section_performance(self, doc: Document, meta: Dict, inference_time: float, stats: Dict):
        self._heading(doc, "8. AI MODULE PERFORMANCE METRICS")

        fps_proc = meta.get("total_frames", 0) / inference_time if inference_time > 0 else 0
        avg_conf = stats.get("avg_confidence", 0)
        model_name = self.config.get("model", {}).get("name", "YOLOv8n")
        device = self.config.get("model", {}).get("device", "cpu")
        frame_skip = self.config.get("video", {}).get("frame_skip", 1)

        t = doc.add_table(rows=0, cols=2)
        t.style = "Table Grid"

        rows_data = [
            ("Model Architecture", model_name),
            ("Inference Device", device.upper()),
            ("Frame Skip Factor", f"{frame_skip}x (every {frame_skip} frames)"),
            ("Total Inference Time", f"{inference_time:.2f} seconds"),
            ("Processing Speed", f"{fps_proc:.1f} frames/second"),
            ("Total Frames Analysed", str(meta.get("total_frames", "N/A"))),
            ("Average Detection Confidence", f"{avg_conf:.4f}"),
            ("Total Unique Detections", str(stats.get("total_detections", 0))),
            ("Sensor Channels Fused", "EO (primary) | IR (if available)"),
            ("Edge Hardware Target", "NVIDIA Jetson Orin NX"),
        ]

        for i, (label, value) in enumerate(rows_data):
            row = t.add_row()
            row.cells[0].text = label
            row.cells[0].paragraphs[0].runs[0].bold = True
            row.cells[0].paragraphs[0].runs[0].font.size = Pt(9)
            row.cells[1].text = value
            row.cells[1].paragraphs[0].runs[0].font.size = Pt(9)
            if i % 2 == 0:
                _set_cell_bg(row.cells[0], ROW_ALT)
                _set_cell_bg(row.cells[1], ROW_ALT)

        _set_col_widths(t, [2.8, 4.0])
        doc.add_paragraph()

    # ── Disclaimer ────────────────────────────────────────────────────────────
    def _section_disclaimer(self, doc: Document):
        self._heading(doc, "⚠  HUMAN-IN-THE-LOOP DISCLAIMER")
        text = (
            "THIS REPORT IS GENERATED BY AN AUTONOMOUS AI SYSTEM AND IS INTENDED SOLELY AS "
            "DECISION SUPPORT. ALL DETECTIONS, THREAT ASSESSMENTS, AND COORDINATE ESTIMATES "
            "MUST BE VERIFIED BY A QUALIFIED HUMAN ANALYST BEFORE ANY OPERATIONAL ACTION IS TAKEN. "
            "THE AI MODULE MAY PRODUCE FALSE POSITIVES OR MISS TARGETS. "
            "NO ACTION SHOULD BE TAKEN BASED SOLELY ON THIS REPORT. "
            f"CLASSIFICATION: {self.classification}."
        )
        p = doc.add_paragraph(text)
        p.runs[0].font.size = Pt(9)
        p.runs[0].bold = True
        p.runs[0].font.color.rgb = HIGH_RED

    # ── Helpers ───────────────────────────────────────────────────────────────
    def _heading(self, doc: Document, text: str):
        p = doc.add_paragraph()
        run = p.add_run(text)
        run.bold = True
        run.font.size = Pt(12)
        run.font.color.rgb = DARK_BG

    def _compute_stats(self, detections: List[Dict]) -> Dict:
        if not detections:
            return {
                "total_detections": 0,
                "by_threat": {"HIGH": 0, "MEDIUM": 0, "LOW": 0},
                "by_category": {},
                "avg_confidence": 0,
            }

        # Deduplicate by track_id
        by_track = {}
        for det in detections:
            tid = det.get("track_id", id(det))
            if tid not in by_track or det.get("confidence", 0) > by_track[tid].get("confidence", 0):
                by_track[tid] = det

        unique = list(by_track.values())

        threat_counts = Counter(d.get("threat_level", "LOW") for d in unique)
        by_category = defaultdict(lambda: {"count": 0, "max_conf": 0.0})
        confs = []

        for det in unique:
            cat = det.get("category", "Unknown")
            by_category[cat]["count"] += 1
            conf = det.get("confidence", 0)
            by_category[cat]["max_conf"] = max(by_category[cat]["max_conf"], conf)
            confs.append(conf)

        return {
            "total_detections": len(unique),
            "by_threat": {
                "HIGH":   threat_counts.get("HIGH", 0),
                "MEDIUM": threat_counts.get("MEDIUM", 0),
                "LOW":    threat_counts.get("LOW", 0),
            },
            "by_category": dict(by_category),
            "avg_confidence": round(sum(confs) / len(confs), 4) if confs else 0,
        }
