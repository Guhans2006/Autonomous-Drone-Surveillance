"""
demo.py — Run DISHTI pipeline on a synthetic test video (no real drone video needed).
Creates a fake video with moving objects and runs the full pipeline.

Usage:
    python demo.py
"""

import sys
import os
import numpy as np
sys.path.insert(0, os.path.dirname(__file__))


def create_synthetic_video(output_path: str = "data/test_video.mp4",
                           duration_sec: int = 15,
                           fps: int = 25,
                           width: int = 1280,
                           height: int = 720):
    """Create a synthetic drone-view video with moving colored boxes."""
    try:
        import cv2
    except ImportError:
        print("OpenCV not installed. Install with: pip install opencv-python")
        return None

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    writer = cv2.VideoWriter(output_path, fourcc, fps, (width, height))

    if not writer.isOpened():
        print("Cannot create video writer. Trying AVI format...")
        output_path = output_path.replace(".mp4", ".avi")
        fourcc = cv2.VideoWriter_fourcc(*"XVID")
        writer = cv2.VideoWriter(output_path, fourcc, fps, (width, height))

    total_frames = duration_sec * fps

    # Define some mock "objects" moving across the frame
    objects = [
        {"label": "vehicle",  "color": (0, 200, 255),  "x": 100, "y": 200, "vx": 3, "vy": 1, "w": 80, "h": 50},
        {"label": "person",   "color": (0, 255, 100),  "x": 600, "y": 400, "vx":-2, "vy": 2, "w": 30, "h": 60},
        {"label": "truck",    "color": (255, 100, 0),  "x": 900, "y": 300, "vx":-3, "vy":-1, "w": 120,"h": 70},
        {"label": "target_4", "color": (255, 50, 50),  "x": 400, "y": 150, "vx": 2, "vy": 3, "w": 60, "h": 60},
    ]

    print(f"Creating synthetic video: {output_path} ({duration_sec}s @ {fps}fps)...")

    for frame_idx in range(total_frames):
        # Background: aerial-view gradient
        frame = np.zeros((height, width, 3), dtype=np.uint8)
        frame[:] = (45, 55, 40)  # dark green ground
        # Grid lines (road/field pattern)
        for gx in range(0, width, 120):
            cv2.line(frame, (gx, 0), (gx, height), (55, 65, 50), 1)
        for gy in range(0, height, 100):
            cv2.line(frame, (0, gy), (width, gy), (55, 65, 50), 1)

        # Draw + update moving objects
        for obj in objects:
            obj["x"] = int(obj["x"] + obj["vx"])
            obj["y"] = int(obj["y"] + obj["vy"])
            # Bounce off edges
            if obj["x"] < 0 or obj["x"] + obj["w"] > width:
                obj["vx"] *= -1
                obj["x"] = max(0, min(obj["x"], width - obj["w"]))
            if obj["y"] < 0 or obj["y"] + obj["h"] > height:
                obj["vy"] *= -1
                obj["y"] = max(0, min(obj["y"], height - obj["h"]))

            cv2.rectangle(frame,
                          (obj["x"], obj["y"]),
                          (obj["x"] + obj["w"], obj["y"] + obj["h"]),
                          obj["color"], -1)
            cv2.putText(frame, obj["label"],
                        (obj["x"], obj["y"] - 5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.45, obj["color"], 1)

        # Frame info overlay
        ts = frame_idx / fps
        cv2.putText(frame, f"DISHTI DEMO  |  {ts:.1f}s  |  Frame {frame_idx}",
                    (20, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (200, 200, 200), 1)

        writer.write(frame)

    writer.release()
    print(f"Synthetic video saved: {output_path}")
    return output_path


if __name__ == "__main__":
    print("=" * 60)
    print("DISHTI Demo — Full Pipeline Test")
    print("=" * 60)

    # Step 1: Create synthetic video
    video_path = create_synthetic_video()
    if video_path is None:
        print("Could not create test video. Provide your own video and run:")
        print("  python main.py your_video.mp4")
        sys.exit(1)

    # Step 2: Run pipeline
    from main import run_pipeline
    report = run_pipeline(
        video_path=video_path,
        config_path="config/config.yaml",
        output_dir="outputs/reports"
    )

    print(f"\nDemo complete!")
    print(f"Report: {report}")
    print(f"Also check outputs/reports/ for the JSON detections file.")
