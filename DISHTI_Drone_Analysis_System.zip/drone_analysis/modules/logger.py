"""Logging setup for DISHTI pipeline."""

import logging
import os
from datetime import datetime


def setup_logger(name: str = "DISHTI", log_to_file: bool = True) -> logging.Logger:
    """Set up and return a configured logger."""
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)

    if logger.handlers:
        return logger

    fmt = logging.Formatter("[%(asctime)s] [%(name)s] [%(levelname)s] %(message)s",
                            datefmt="%H:%M:%S")

    # Console handler
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    ch.setFormatter(fmt)
    logger.addHandler(ch)

    # File handler
    if log_to_file:
        os.makedirs("outputs", exist_ok=True)
        log_file = f"outputs/dishti_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
        fh = logging.FileHandler(log_file)
        fh.setLevel(logging.DEBUG)
        fh.setFormatter(fmt)
        logger.addHandler(fh)

    return logger
